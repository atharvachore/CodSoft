import json
import os

# Task class to represent each to-do item
class Task:
    def __init__(self, title, description, due_date, completed=False):
        self.title = title
        self.description = description
        self.due_date = due_date
        self.completed = completed

    def mark_complete(self):
        self.completed = True

    def update(self, title=None, description=None, due_date=None):
        if title:
            self.title = title
        if description:
            self.description = description
        if due_date:
            self.due_date = due_date

# To-Do List class to manage all tasks
class ToDoList:
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        self.tasks.append(task)

    def display_tasks(self):
        if not self.tasks:
            print("\nNo tasks to display!")
        else:
            print("\nTo-Do List:")
            for i, task in enumerate(self.tasks, start=1):
                status = "Completed" if task.completed else "Pending"
                print(f"{i}. {task.title} - {status} (Due: {task.due_date})")
                print(f"   Description: {task.description}")

    def delete_task(self, index):
        if 0 <= index < len(self.tasks):
            self.tasks.pop(index)
        else:
            print("Invalid task number!")

    def mark_task_complete(self, index):
        if 0 <= index < len(self.tasks):
            self.tasks[index].mark_complete()
        else:
            print("Invalid task number!")

    def update_task(self, index, title=None, description=None, due_date=None):
        if 0 <= index < len(self.tasks):
            self.tasks[index].update(title, description, due_date)
        else:
            print("Invalid task number!")

    def save_tasks(self, filename="tasks.json"):
        with open(filename, 'w') as file:
            # Save task list with all task attributes, including completion status
            json.dump([task.__dict__ for task in self.tasks], file)
        print("Tasks saved successfully!")

    def load_tasks(self, filename="tasks.json"):
        if os.path.exists(filename):
            try:
                with open(filename, 'r') as file:
                    task_dicts = json.load(file)
                    # Convert loaded dictionaries back into Task objects
                    self.tasks = [Task(**task_dict) for task_dict in task_dicts]
                print("Tasks loaded successfully!")
            except json.JSONDecodeError:
                print("Error: Could not decode tasks from file. The file may be corrupted.")
        else:
            print("No saved tasks found. Please add and save tasks first.")

# Helper functions for user input and menu handling
def create_task():
    title = input("Enter task title: ")
    description = input("Enter task description: ")
    due_date = input("Enter due date: ")
    return Task(title, description, due_date)

def show_menu():
    print("\nTo-Do List Menu:")
    print("1. Add Task")
    print("2. View Tasks")
    print("3. Update Task")
    print("4. Mark Task as Complete")
    print("5. Delete Task")
    print("6. Save Tasks")
    print("7. Load Tasks")
    print("8. Exit")

# Main function to run the application
def main():
    to_do_list = ToDoList()

    while True:
        show_menu()
        choice = input("\nEnter your choice (1-8): ")

        if choice == '1':
            task = create_task()
            to_do_list.add_task(task)
            print("Task added successfully!")
        elif choice == '2':
            to_do_list.display_tasks()
        elif choice == '3':
            task_num = int(input("Enter task number to update: ")) - 1
            title = input("Enter new title (or press Enter to skip): ")
            description = input("Enter new description (or press Enter to skip): ")
            due_date = input("Enter new due date (or press Enter to skip): ")
            to_do_list.update_task(task_num, title or None, description or None, due_date or None)
            print("Task updated successfully!")
        elif choice == '4':
            task_num = int(input("Enter task number to mark as complete: ")) - 1
            to_do_list.mark_task_complete(task_num)
            print("Task marked as complete!")
        elif choice == '5':
            task_num = int(input("Enter task number to delete: ")) - 1
            to_do_list.delete_task(task_num)
            print("Task deleted successfully!")
        elif choice == '6':
            to_do_list.save_tasks()
        elif choice == '7':
            to_do_list.load_tasks()
        elif choice == '8':
            print("Exiting the application.")
            break
        else:
            print("Invalid choice. Please select again.")

if __name__ == "__main__":
    main()